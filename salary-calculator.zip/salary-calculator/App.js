import {useState, useEffect} from 'react';
import { Text, SafeAreaView, StyleSheet, Button } from 'react-native';
import Form from './components/Form';
import Result from './components/Result';
import Footer from './components/Footer';

export default function App() {
  const [name, setName] = useState(null);
  const [salary, setSalary] = useState(null);
  const [totalSalary, setTotalSalary] = useState(null);

  const calculateSalary = () => {
    const afp = salary * 0.04;
    const isss = salary * 0.03;
    const salaryWithDiscounts = (salary - isss - afp);
    const total = salaryWithDiscounts - (salaryWithDiscounts * 0.05);
    setTotalSalary(total);
  }

  return (
    <>
    <SafeAreaView>
      <Text style={styles.Title}>Calculadora Salario</Text>
      <Form
        setName={setName}
        setSalary={setSalary}
      />
      <Result
        name={name}
        totalSalary={totalSalary}
      />
      <Footer calculateSalary={calculateSalary}/>
    </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  Title:{
    fontSize: 25,
    margin: 'auto',
    paddingTop:50,
    paddingLeft:70,
    paddingRight:70,
    fontFamily:"Arial",
    fontWeight: 'bold'
  }
});