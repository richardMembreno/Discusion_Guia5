import {StyleSheet, View, Text, TouchableOpacity} from 'react-native';

export default function Footer(props){
  const {calculateSalary} = props;
  return(
    <View>
      <TouchableOpacity onPress={calculateSalary} style={styles.buttonContainer}>
        <Text style={styles.buttonText}>Calcular</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  buttonContainer:{
    elevation: 8,
    backgroundColor:'#5F76EA',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
    width:"85%",
    marginHorizontal:25
  },
  buttonText:{
    fontSize: 18,
    color: "#fff",
    fontWeight: "bold",
    alignSelf: "center",
    textTransform: "uppercase"
  }
});