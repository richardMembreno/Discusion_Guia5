import React from 'react';
import {StyleSheet, TextInput, View} from 'react-native';

export default function Form(props){
  const {setName, setSalary} = props;

  return(
    <View>
      <View>
        <TextInput 
          style={styles.input}
          placeholder="Ingresar Nombre:"
          keyboardType="default"
          onChange={(e) => setName(e.nativeEvent.text)}
        />
      </View>
      <View>
        <TextInput
          style={styles.input}
          placeholder="Ingresar Salario"
          keyboardType="numeric"
          onChange={(e) => setSalary(e.nativeEvent.text)}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  input:{
    borderColor: "gray",
    width: "90%",
    borderWidth: 1,
    borderRadius: 10,
    padding: 10,
    marginTop: 25,
    marginLeft:15,
    marginRight:15
  }
});