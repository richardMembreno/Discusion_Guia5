import {StyleSheet, Text, View} from 'react-native';

export default function Result(props){
  const {totalSalary, name} = props;
return(
  <View style={styles.Container}>
    <Text style={styles.Title}>Resultado</Text>
    <Text style={styles.ResultText}>Nombre: {name}</Text>
    <Text style={styles.ResultText}>Salario Neto: ${totalSalary}</Text>
  </View>
);

}

const styles = StyleSheet.create({
  Title:{
    fontSize:22,
    fontWeight:'bold',
    textAlign:"center",
    paddingVertical:10
  },
  ResultText:{
    fontSize:18,
    textAlign:"center",
    paddingVertical:5
  },
  Container:{
    justifyContent:"center",
    padding:15
  }
});